<script lang="ts">
  import type { PageData } from './$types';

  // This 'data' variable automatically contains 
  // everything you returned from the load function
  let data = $props<PageData>();
</script>

<h1>Dashboard</h1>
<p>Welcome, {data.session.email}!</p>
<p>Active Sessions: {data.activeSessions}</p>

<h2>Bus Status</h2>
<ul>
  {#each data.busStatus as service}
    <li>{service.name}: {service.state} (Uptime: {service.uptime}s)</li>
  {/each}
</ul>
